/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tests;

import modele.TypeCheval;

/**
 *
 * @author sio2
 */
public class TypeChevalTest {
    
       public static void main(String[] args) {
       
           TypeCheval unTypCheval = new TypeCheval(455,"Pure sang","Un cheval qui a ses parents anglais");
           System.out.println(unTypCheval.getId() + " " + unTypCheval.getLibelle() + " " + unTypCheval.getDescription());
           
       
       
       
       
       
       
       
       
       
       
       }
    
}
